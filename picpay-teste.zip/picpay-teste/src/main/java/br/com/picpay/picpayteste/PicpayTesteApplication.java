package br.com.picpay.picpayteste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicpayTesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicpayTesteApplication.class, args);
	}

}
